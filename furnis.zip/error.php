<?php 
die('Página não encontrada!');
?>